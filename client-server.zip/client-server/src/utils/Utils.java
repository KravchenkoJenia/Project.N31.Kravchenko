package utils;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;

public class Utils {

    private ArrayList<String> sonnets;

    private static Utils instance;

    public static Utils getInstance(){
        if(instance == null){
            try {
                instance = new Utils();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return instance;
    }

    private Utils() throws IOException {
        File file = new File ("src/sonnets.txt");
        FileReader fread = new FileReader(file);
        BufferedReader bfread = new BufferedReader(fread);
        sonnets = new ArrayList<>();
        while (bfread.ready())
        {
            sonnets.add(bfread.readLine());
        }
    }

    public ArrayList<String> getSonnets() {
        return sonnets;
    }

    public String getRandomSonnet(){
        Random random = new Random();
        return sonnets.get(random.nextInt(154));
    }
}
