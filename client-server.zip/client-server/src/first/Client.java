package first;


import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    private static Socket clientSocket; //сокет для общения

    public static void main(String[] args) throws IOException {
        Scanner resScanner = new Scanner(System.in);
        System.out.println("Enter GET to get a random sonnet.");
        clientSocket = new Socket(InetAddress.getLocalHost(), 8082);
        PrintWriter pw = new PrintWriter(clientSocket.getOutputStream(), true);
        ServerConnection serverConnection = new ServerConnection(clientSocket);
        new Thread(serverConnection).start();
        while (true) {
            String command = resScanner.nextLine();
            pw.println(command);
        }

    }

}
