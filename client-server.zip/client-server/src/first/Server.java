package first;

import utils.Utils;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Server {
    public static LinkedList<ClientHandler> serverList = new LinkedList<>();
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(8082);
        while (true){
            Socket socket = serverSocket.accept();
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            ClientHandler clientHandler = new ClientHandler(socket);
            serverList.add(clientHandler);
        }
    }

}

class SendMessage extends Thread{
    ClientHandler clientHandler;

    public SendMessage(ClientHandler clientHandler){
        this.clientHandler = clientHandler;
    }

    @Override
    public void run() {
        while(true) {
            try {
                Thread.sleep(60000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            clientHandler.out.println("SUB: " + Utils.getInstance().getRandomSonnet());

        }
    }
}

class ClientHandler extends Thread{
    private ArrayList<String> sonnets;
    private Socket socket;
    private String hostName;
    long mainTime;

    private BufferedReader in; // поток чтения из сокета
    public PrintWriter out; // поток записи в сокет

    public ClientHandler(Socket socket) throws IOException {
        this.socket = socket;
        sonnets = Utils.getInstance().getSonnets();
        hostName = socket.getInetAddress().getHostName();
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);
        start();
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    @Override
    public void run() {
        PrintWriter out;
        try {
            out = new PrintWriter(socket.getOutputStream());
            Scanner in = new Scanner(socket.getInputStream());
            while (true) {

                String req = in.nextLine();

                if (req.contains("QUIT")) {
                    try (FileWriter writer = new FileWriter("src/clients.txt", false)) {
                        System.out.print("");
                        writer.flush();
                    } catch (IOException ex) {
                        System.out.println(ex.getMessage());
                    }
                    System.exit(0);
                }

                if (req.contains("REGISTER:")) {
                    hostName = req.split(":")[1];
                    out.println("Registered user is: " + hostName);
                    SendMessage message = new SendMessage(this);
                    Thread t = new Thread(message);
                    t.start();
                    try (FileWriter writer = new FileWriter("src/clients.txt", true)) {
                        writer.write(hostName);
                        writer.append('\n');
                        writer.flush();
                    } catch (IOException ex) {
                        System.out.println(ex.getMessage());
                    }
                }

                if (req.equals("GET")) {
                    System.out.println("[SERVER GET]: " + req + " from " + hostName);
                    String m = Utils.getInstance().getRandomSonnet();
                    System.out.println("[SERVER SEND]: " + m + "(to " + hostName + ")");
                    out.println(m);
                }

                if (req.contains("TO_REGISTERED:")) {
                    String msg = req.split(":")[1];
                    ArrayList<String> clients = readFile("src/clients.txt");

                    for (ClientHandler c : Server.serverList) {
                        for(String s : clients){
                            if(s.equals(c.hostName)){
                                System.out.println("[SERVER SEND]: " + msg + " (to " + c.hostName + ")");
                                c.out.println(hostName + ": " + msg);
                                c.out.flush();
                                break;
                            }
                        }
                    }
                }
                if (req.contains("TO_ALL:")) {
                    String msg = req.split(":")[1];
                    for (ClientHandler c : Server.serverList) {
                                System.out.println("[SERVER SEND]: " + msg + " (to " + c.hostName + ")");
                                c.out.println(hostName + ": " + msg);
                                c.out.flush();
                        }
                    }
                out.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<String> readFile(String path) throws FileNotFoundException {
        return (ArrayList<String>) new BufferedReader(new InputStreamReader(new FileInputStream(path)))
                .lines()
                .collect(Collectors.toList());
    }

    public String getTime(){
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        String stringTime = sdf.format(date);
        return stringTime;
    }
}

